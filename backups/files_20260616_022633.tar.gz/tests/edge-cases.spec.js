const { test, expect } = require('@playwright/test');

/**
 * Edge Cases Testing - SKD CAT-BKN
 * Tests for boundary conditions, error handling, and unusual scenarios
 */

test.describe('Edge Cases — Error Handling', () => {
  test('handles invalid session ID gracefully', async ({ request }) => {
    const response = await request.get('http://localhost/permen/api/get_soal.php?session_id=999999');
    // May return 401 or 500 due to global error handler
    expect([401, 500]).toContain(response.status());
    const data = await response.json();
    expect(data.error || data.message).toBeTruthy();
  });

  test('handles missing session ID parameter', async ({ request }) => {
    const response = await request.get('http://localhost/permen/api/get_soal.php');
    // May return 400 or 500 due to global error handler
    expect([400, 500]).toContain(response.status());
    const data = await response.json();
    expect(data.error || data.message).toBeTruthy();
  });

  test('handles invalid no_hp format in login', async ({ page }) => {
    await page.goto('http://localhost/permen/pages/login.php');
    await page.fill('input[name="no_hp"]', 'invalid-no-hp');
    await page.fill('input[name="password"]', 'password');
    await page.click('button[type="submit"]');
    // Should stay on login page with error
    await expect(page).toHaveURL(/login\.php/);
  });

  test('handles wrong password in login', async ({ page }) => {
    await page.goto('http://localhost/permen/pages/login.php');
    await page.fill('input[name="no_hp"]', '081987654321');
    await page.fill('input[name="password"]', 'wrongpassword');
    await page.click('button[type="submit"]');
    // Should stay on login page with error
    await expect(page).toHaveURL(/login\.php/);
  });
});

test.describe('Edge Cases — Navigation', () => {
  test('handles direct access to protected pages without login', async ({ page }) => {
    await page.goto('http://localhost/permen/pages/user_dashboard.php');
    await expect(page).toHaveURL(/login\.php/);
  });

  test('handles direct access to admin dashboard without admin role', async ({ page }) => {
    // Login as regular user
    await page.goto('http://localhost/permen/pages/login.php');
    await page.waitForLoadState('domcontentloaded', { timeout: 10000 });
    await page.fill('input[name="no_hp"]', '081987654321');
    await page.fill('input[name="password"]', 'password');
    await page.click('button[type="submit"]');
    await page.waitForLoadState('domcontentloaded', { timeout: 10000 });
    await page.waitForURL(/user_dashboard\.php/, { timeout: 15000 });

    // Try to access admin dashboard
    await page.goto('http://localhost/permen/pages/admin_dashboard.php');
    await page.waitForLoadState('domcontentloaded', { timeout: 10000 });
    // Should redirect to login or user dashboard
    const currentUrl = page.url();
    expect(currentUrl).toMatch(/login\.php|user_dashboard\.php/);
  });

  test('handles invalid materi subtes parameter', async ({ page }) => {
    await page.goto('http://localhost/permen/pages/materi.php?subtes=INVALID');
    // Should default to TWK
    await expect(page).toHaveTitle(/Materi TWK/);
  });
});

test.describe('Edge Cases — Tryout Scenarios', () => {
  test('handles tryout with no questions available', async ({ page }) => {
    // This test would require mocking the database to have no questions
    // For now, we'll skip this as it requires database manipulation
    test.skip();
  });

  test('handles tryout timeout gracefully', async ({ page }) => {
    // This test would require manipulating timers
    // For now, we'll skip this as it requires complex setup
    test.skip();
  });
});

test.describe('Edge Cases — API Rate Limiting', () => {
  test('respects rate limiting on login attempts', async ({ page }) => {
    // Rate limiting is disabled in development for testing
    // Skip this test in development environment
    test.skip();
  });
});

test.describe('Edge Cases — CSRF Protection', () => {
  test('rejects form submission without CSRF token', async ({ request }) => {
    const response = await request.post('http://localhost/permen/pages/login.php', {
      form: {
        no_hp: '081987654321',
        password: 'password',
        // Missing csrf_token
      }
    });
    // Should reject or redirect
    expect([200, 302]).toContain(response.status());
  });
});

test.describe('Edge Cases — XSS Protection', () => {
  test('escapes HTML in user-generated content', async ({ page }) => {
    // This would require testing with XSS payloads
    // For now, we'll skip as it requires specific test data
    test.skip();
  });
});
