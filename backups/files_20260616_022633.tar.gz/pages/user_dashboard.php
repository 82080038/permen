<?php
require '../config.php';
require '../helpers.php';

// Guard: only logged in
if (empty($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = (int)$_SESSION['user_id'];
$userName = e($_SESSION['user_nama'] ?? 'Peserta');
$userRole = $_SESSION['user_role'] ?? 'user';

// Fetch user info with instansi
$stmt = $pdo->prepare("SELECT u.nama, u.no_hp, u.email, u.target_instansi, u.created_at, u.target_instansi, u.target_instansi, i.nama as instansi_nama, i.nama as instansi_nama, i.deskripsi as instansi_desk 
    FROM users u LEFT JOIN instansi i ON u.target_instansi = i.id WHERE u.id = ?");
$stmt->execute([$userId]);
$userInfo = $stmt->fetch();

// Fetch riwayat tryout
$stmt = $pdo->prepare("SELECT * FROM tryout_sessions WHERE user_id = ? ORDER BY id DESC");
$stmt->execute([$userId]);
$riwayat = $stmt->fetchAll();

// Calculate stats
$totalTryout = count($riwayat);
$selesai = array_filter($riwayat, fn($r) => $r['status'] === 'selesai');
$rataNilai = 0;
$bestScore = 0;
$subtesTerlemah = '-';

// Get latest completed tryout
$latestScore = null;
if (!empty($selesai)) {
    // Re-index array to ensure reset() works correctly
    $selesai = array_values($selesai);
    $latestScore = $selesai[0] ?? null;
    // Debug: check if latestScore is set
    if (!$latestScore) {
        // Try to get the first element directly
        $latestScore = reset($selesai);
    }
}

if (count($selesai) > 0) {
    $totalNilai = array_sum(array_column($selesai, 'total_nilai'));
    $rataNilai = round($totalNilai / count($selesai));
    $bestScore = max(array_column($selesai, 'total_nilai'));

    // Cari subtes terlemah (rata-rata nilai per subtes)
    $tkpScores = array_column($selesai, 'nilai_tkp');
    $tiuScores = array_column($selesai, 'nilai_tiu');
    $twkScores = array_column($selesai, 'nilai_twk');
    $avgTkp = count($tkpScores) ? round(array_sum($tkpScores) / count($tkpScores)) : 0;
    $avgTiu = count($tiuScores) ? round(array_sum($tiuScores) / count($tiuScores)) : 0;
    $avgTwk = count($twkScores) ? round(array_sum($twkScores) / count($twkScores)) : 0;
    $min = min($avgTkp, $avgTiu, $avgTwk);
    if ($min === $avgTkp && $min > 0) $subtesTerlemah = 'TKP';
    elseif ($min === $avgTiu && $min > 0) $subtesTerlemah = 'TIU';
    elseif ($min === $avgTwk && $min > 0) $subtesTerlemah = 'TWK';
}

// Passing grades dari subtes_config (dinamis)
$passingMap = $pdo->query("SELECT subtes, passing_grade FROM subtes_config WHERE is_active = 1")->fetchAll(PDO::FETCH_KEY_PAIR);
$passingTkp = (int)($passingMap['TKP'] ?? 126);
$passingTiu = (int)($passingMap['TIU'] ?? 80);
$passingTwk = (int)($passingMap['TWK'] ?? 65);
$passingTotal = (int)($passingMap['TKP'] ?? 126) + (int)($passingMap['TIU'] ?? 80) + (int)($passingMap['TWK'] ?? 65);

// Ambil rekomendasi materi
$rekomendasiMateri = $pdo->query("SELECT * FROM rekomendasi_materi WHERE aktif = 1 ORDER BY urutan")->fetchAll();

// Analisis akurasi per topik (butuh minimal 1 jawaban)
$akurasiTopik = $pdo->prepare("
    SELECT 
        q.subtes,
        q.topik,
        COUNT(*) as total,
        SUM(a.is_benar) as benar
    FROM answers a
    JOIN questions q ON a.question_id = q.id
    JOIN tryout_sessions ts ON a.session_id = ts.id
    WHERE ts.user_id = ? AND a.jawaban IS NOT NULL AND a.jawaban != ''
    GROUP BY q.subtes, q.topik
    HAVING COUNT(*) >= 3
    ORDER BY subtes, SUM(a.is_benar) ASC, COUNT(*) DESC
    LIMIT 10
");
$akurasiTopik->execute([$userId]);
$topikStats = $akurasiTopik->fetchAll(PDO::FETCH_ASSOC);

// Fetch user's bookmarked materials with progress
$bookmarksStmt = $pdo->prepare("
    SELECT mb.materi_id, mb.created_at, mp.progress_percent, mp.last_read_at
    FROM materi_bookmarks mb
    LEFT JOIN materi_progress mp ON mb.user_id = mp.user_id AND mb.materi_id = mp.materi_id
    WHERE mb.user_id = ?
    ORDER BY mb.created_at DESC
    LIMIT 10
");
$bookmarksStmt->execute([$userId]);
$bookmarks = $bookmarksStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch latest performance report
$stmt = $pdo->prepare("
    SELECT * FROM performance_reports 
    WHERE user_id = ? 
    ORDER BY created_at DESC 
    LIMIT 1
");
$stmt->execute([$userId]);
$performanceReport = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
<meta name="theme-color" content="#1a5276">
<title>Dashboard Peserta — SKD CAT-BKN</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}body{font-family:'Segoe UI',Arial,sans-serif;background:#f5f7fa;color:#222;line-height:1.6;-webkit-text-size-adjust:100%;transition:background .2s,color .2s}
:root{--bg-body:#f5f7fa;--bg-card:#fff;--text-main:#222;--text-muted:#555;--header-bg:#1a5276;--border-color:#eee;--link-color:#2980b9;--success-bg:#d4edda;--danger-bg:#f8d7da;--warning-bg:#fff3cd}
[data-theme="dark"]{--bg-body:#1a1a2e;--bg-card:#16213e;--text-main:#e8e8e8;--text-muted:#d0d0d0;--header-bg:#0f3460;--border-color:#555;--link-color:#74b9ff;--success-bg:#1e3a2f;--danger-bg:#3a1e2f;--warning-bg:#3a3010}
body{background:var(--bg-body);color:var(--text-main)}
.header{background:var(--header-bg);color:#fff;padding:.8rem 1rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.4rem}
.header h1{font-size:1.1rem;white-space:nowrap}.header div{display:flex;flex-wrap:wrap;gap:.4rem .8rem;align-items:center}
.header a{color:#fff;text-decoration:none;font-size:.85rem;white-space:nowrap;min-height:44px;display:flex;align-items:center}
.container{max-width:1000px;margin:1.5rem auto;padding:0 1rem}
.welcome{background:var(--bg-card);border-radius:8px;padding:1.2rem;box-shadow:0 2px 6px rgba(0,0,0,.08);margin-bottom:1.5rem}
.welcome h2{color:#1a5276;font-size:1.15rem;margin-bottom:.3rem}
.welcome p{color:#555;font-size:.9rem}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:.8rem;margin-bottom:1.5rem}
.stat{background:var(--bg-card);border-radius:8px;padding:.9rem;box-shadow:0 2px 6px rgba(0,0,0,.08);text-align:center}
.stat .num{font-size:1.6rem;font-weight:bold;color:#2980b9}
.stat .label{color:#555;font-size:.85rem;margin-top:.3rem}
.stat .sub{color:#777;font-size:.75rem}
.actions{display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:1.5rem;overflow-x:auto;-webkit-overflow-scrolling:touch}
.btn{display:inline-block;background:#2980b9;color:#fff;padding:.55rem .9rem;border-radius:6px;text-decoration:none;font-weight:600;font-size:.9rem;min-height:44px;min-width:44px;white-space:nowrap}
.btn:hover{background:#1a5276}
.btn.success{background:#27ae60}
.btn.warning{background:#e67e22}
.btn.danger{background:#e74c3c}
.section{background:var(--bg-card);border-radius:8px;padding:1.2rem;box-shadow:0 2px 6px rgba(0,0,0,.08);margin-bottom:1.2rem;overflow:hidden}
.section h2{color:#1a5276;font-size:1.05rem;margin-bottom:.8rem;border-bottom:2px solid #eaf2f8;padding-bottom:.4rem}
.table-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch}
table{width:100%;border-collapse:collapse;font-size:.85rem;min-width:500px}
th,td{border:1px solid var(--border-color);padding:.4rem .5rem;text-align:left}
th{background:var(--bg-body);color:var(--text-muted);border-color:var(--border-color)}
tr:hover{background:#f8f9fa}
.badge{display:inline-block;padding:.2rem .5rem;border-radius:10px;font-size:.75rem;font-weight:bold}
.badge.lulus{background:var(--success-bg);color:#27ae60}
.badge.gagal{background:var(--danger-bg);color:#e74c3c}
.badge.berjalan{background:var(--warning-bg);color:#f39c12}
.empty{color:#777;font-style:italic;text-align:center;padding:2rem}
.rekomendasi{background:var(--bg-body);border-left:4px solid var(--link-color);padding:1rem;border-radius:0 6px 6px 0;margin-top:1rem}
.rekomendasi h3{color:#1a5276;font-size:1rem;margin-bottom:.3rem}
.rekomendasi p{color:#444;font-size:.9rem}
.footer{text-align:center;padding:1.2rem;color:#777;font-size:.85rem;margin-top:1.5rem}
@media(max-width:600px){
.stats{grid-template-columns:repeat(2,1fr)}
.actions{flex-wrap:nowrap}
.section{padding:1rem}
}
@media(max-width:380px){
.stats{grid-template-columns:1fr}
}
.skip-link:focus{top:0}
.theme-toggle{background:transparent;border:1px solid rgba(255,255,255,.4);color:#fff;padding:.2rem .5rem;border-radius:4px;cursor:pointer;font-size:.8rem;margin-right:.3rem;min-height:44px;min-width:44px}
.topic-bar{margin-bottom:.8rem}
.topic-bar-header{display:flex;justify-content:space-between;font-size:.85rem;margin-bottom:.2rem}
.topic-bar-track{background:#e9ecef;border-radius:10px;height:20px;overflow:hidden}
.topic-bar-fill{height:100%;border-radius:10px;transition:width .3s ease}
.topic-bar-fill.high{background:#27ae60}.topic-bar-fill.mid{background:#f39c12}.topic-bar-fill.low{background:#e74c3c}
.topic-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:1rem}
</style>
</head>
<body>
<a href="#main-content" class="skip-link" style="position:absolute;top:-40px;left:0;background:#1a5276;color:#fff;padding:8px;z-index:1000;transition:top 0.3s">Lanjut ke konten utama</a>
<?php $pageTitle = 'Dashboard Peserta — SKD CAT-BKN'; $activePage = 'user_dashboard'; $showThemeToggle = true; $showNotifications = true; $showAdminLink = true; ?>
<?php require '../includes/navigation.php'; ?>
<?php 
$breadcrumbs = [
    ['label' => 'Beranda', 'url' => '/index.php'],
    ['label' => 'Dashboard', 'url' => '']
];
require '../includes/breadcrumbs.php'; 
?>

<div class="container" id="main-content">
<div class="welcome">
<h2>Selamat datang, <?= $userName ?>!</h2>
<p>
<strong>Nomor HP:</strong> <?= e($userInfo['no_hp'] ?? '-') ?><br>
<?php if ($userInfo['sekolah_asal']): ?>
<strong>Sekolah Asal:</strong> <?= e($userInfo['sekolah_asal']) ?> (<?= e($userInfo['tahun_tamat'] ?? '-') ?>)<br>
<?php endif; ?>
<?php if ($userInfo['instansi_nama']): ?>
<strong>Instansi Pilihan:</strong> <?= e($userInfo['instansi_kode']) ?> — <?= e($userInfo['instansi_nama']) ?><br>
<small style="color:#666"><?= e($userInfo['instansi_desk'] ?? '') ?></small>
<?php else: ?>
<strong>Belum memilih instansi.</strong> <a href="profile.php" style="color:#2980b9">Pilih instansi di profil</a> untuk mendapatkan rekomendasi.
<?php endif; ?>
</p>
</div>

<div class="actions">
<a href="daily_quiz.php" class="btn" style="background:#e74c3c">Daily Quiz Hari Ini</a>
<a href="tryout.php" class="btn danger">Mulai Try Out Penuh</a>
<a href="latihan.php" class="btn success">Latihan per Subtes</a>
<a href="riwayat_soal.php" class="btn" style="background:#8e44ad">Riwayat Soal</a>
<a href="materi.php?subtes=TWK" class="btn warning">Materi TWK</a>
<a href="materi.php?subtes=TIU" class="btn warning">Materi TIU</a>
<a href="materi.php?subtes=TKP" class="btn warning">Materi TKP</a>
</div>

<div class="stats">
<div class="stat"><div class="num"><?= $totalTryout ?></div><div class="label">Total Tryout</div></div>
<div class="stat"><div class="num"><?= count($selesai) ?></div><div class="label">Selesai</div></div>
<div class="stat"><div class="num"><?= $rataNilai ?></div><div class="label">Rata-rata Nilai</div></div>
<div class="stat"><div class="num"><?= $bestScore ?></div><div class="label">Nilai Tertinggi</div></div>
<div class="stat"><div class="num" style="color:#e74c3c"><?= $subtesTerlemah ?></div><div class="label">Subtes Terlemah</div></div>
</div>

<!-- Performance Report -->
<?php if ($performanceReport): ?>
<div class="section">
<h2>📊 Laporan Performa (<?= ucfirst($performanceReport['report_type']) ?>)</h2>
<p style="font-size:.85rem;color:#666;margin-bottom:1rem">Periode: <?= date('d M Y', strtotime($performanceReport['period_start'])) ?> - <?= date('d M Y', strtotime($performanceReport['period_end'])) ?></p>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:1rem;margin-bottom:1rem">
    <div style="background:#f8f9fa;padding:1rem;border-radius:6px;text-align:center">
        <div style="font-size:.8rem;color:#666">Tryout</div>
        <div style="font-size:1.3rem;font-weight:bold;color:#2980b9"><?= $performanceReport['total_tryouts'] ?></div>
        <div style="font-size:.75rem;color:#777">Rata: <?= round($performanceReport['avg_tryout_score']) ?></div>
    </div>
    <div style="background:#f8f9fa;padding:1rem;border-radius:6px;text-align:center">
        <div style="font-size:.8rem;color:#666">Daily Quiz</div>
        <div style="font-size:1.3rem;font-weight:bold;color:#e74c3c"><?= $performanceReport['total_daily_quizzes'] ?></div>
        <div style="font-size:.75rem;color:#777">Rata: <?= round($performanceReport['avg_daily_quiz_score']) ?></div>
    </div>
    <div style="background:#f8f9fa;padding:1rem;border-radius:6px;text-align:center">
        <div style="font-size:.8rem;color:#666">Streak</div>
        <div style="font-size:1.3rem;font-weight:bold;color:#f39c12">🔥 <?= $performanceReport['current_streak'] ?></div>
        <div style="font-size:.75rem;color:#777">Hari</div>
    </div>
    <div style="background:#f8f9fa;padding:1rem;border-radius:6px;text-align:center">
        <div style="font-size:.8rem;color:#666">Latihan</div>
        <div style="font-size:1.3rem;font-weight:bold;color:#27ae60"><?= $performanceReport['total_practice_sessions'] ?></div>
        <div style="font-size:.75rem;color:#777">Sesi</div>
    </div>
</div>
<div style="background:#fff3cd;border-left:4px solid #f1c40f;padding:1rem;border-radius:4px">
    <div style="font-weight:bold;color:#856404;font-size:.9rem;margin-bottom:.3rem">💡 Rekomendasi:</div>
    <div style="font-size:.85rem;color:#555"><?= e($performanceReport['recommendations']) ?></div>
</div>
</div>
<?php endif; ?>

<?php if (empty($selesai)): ?>
<!-- Empty State -->
<div class="section" style="text-align:center;padding:3rem 1rem">
<div style="font-size:3rem;margin-bottom:1rem">📊</div>
<h3 style="color:#555;margin-bottom:.5rem">Belum ada data tryout</h3>
<p style="color:#777;font-size:.9rem;margin-bottom:1.5rem">Mulai tryout pertama Anda untuk melihat grafik progress dan analisis performa.</p>

<?php
// Fetch available packages
$packages = $pdo->query("SELECT * FROM tryout_packages WHERE is_active = 1 ORDER BY FIELD(tingkat_kesulitan, 'mudah', 'sedang', 'sulit')")->fetchAll();
?>
<div style="margin-bottom:1.5rem">
    <label style="display:block;margin-bottom:.5rem;font-weight:bold">Pilih Paket Soal:</label>
    <select id="packageSelect" style="padding:.5rem;border:1px solid #ddd;border-radius:4px;width:100%;max-width:300px;margin:0 auto">
        <option value="0">Default (Sedang)</option>
        <?php foreach ($packages as $pkg): ?>
        <option value="<?= $pkg['id'] ?>"><?= e($pkg['nama']) ?> - Passing: TWK <?= $pkg['passing_grade_twk'] ?>, TIU <?= $pkg['passing_grade_tiu'] ?>, TKP <?= $pkg['passing_grade_tkp'] ?></option>
        <?php endforeach; ?>
    </select>
</div>

<div style="margin-bottom:1.5rem">
    <label style="display:flex;align-items:center;justify-content:center;gap:.5rem;cursor:pointer">
        <input type="checkbox" id="strictModeCheck" style="width:18px;height:18px">
        <span style="font-size:.9rem;color:#555">Aktifkan Strict Mode (tidak bisa kembali ke soal sebelumnya)</span>
    </label>
</div>
<a href="tryout.php" class="btn" style="background:#2980b9;color:#fff;text-decoration:none;padding:.75rem 1.5rem;border-radius:5px;display:inline-block" onclick="startTryoutWithOptions(event)">Mulai Try Out</a>
</div>
<script>
function startTryoutWithOptions(e) {
    e.preventDefault();
    const strictMode = document.getElementById('strictModeCheck').checked ? 1 : 0;
    const packageId = document.getElementById('packageSelect').value;
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = 'tryout.php';
    
    const strictInput = document.createElement('input');
    strictInput.type = 'hidden';
    strictInput.name = 'strict_mode';
    strictInput.value = strictMode;
    form.appendChild(strictInput);
    
    const packageInput = document.createElement('input');
    packageInput.type = 'hidden';
    packageInput.name = 'package_id';
    packageInput.value = packageId;
    form.appendChild(packageInput);
    
    document.body.appendChild(form);
    form.submit();
}
</script>
<?php else: ?>
<!-- Enhanced Progress Chart -->
<div class="section">
<h2>Grafik Perkembangan Nilai per Subtes</h2>
<div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:1rem">
    <button class="btn" style="font-size:.8rem" onclick="updateLineChart('total')" aria-label="Tampilkan grafik total skor">Total</button>
    <button class="btn" style="font-size:.8rem" onclick="updateLineChart('tkp')" aria-label="Tampilkan grafik skor TKP">TKP</button>
    <button class="btn" style="font-size:.8rem" onclick="updateLineChart('tiu')" aria-label="Tampilkan grafik skor TIU">TIU</button>
    <button class="btn" style="font-size:.8rem" onclick="updateLineChart('twk')" aria-label="Tampilkan grafik skor TWK">TWK</button>
</div>
<div style="position:relative;height:350px">
    <canvas id="progressChart"></canvas>
</div>
</div>

<!-- National Average Comparison -->
<div class="section">
<h2>Perbandingan dengan Rata-rata Nasional</h2>
<div style="position:relative;height:300px">
    <canvas id="comparisonChart"></canvas>
</div>
</div>

<!-- Learning Activity Heatmap -->
<div class="section">
<h2>Heatmap Aktivitas Belajar (30 Hari Terakhir)</h2>
<p style="font-size:.9rem;color:#555;margin-bottom:1rem">Intensitas belajar Anda dalam 30 hari terakhir</p>
<div id="activityHeatmap" style="display:flex;flex-wrap:wrap;gap:4px;justify-content:center;margin-bottom:1rem"></div>
<div style="display:flex;justify-content:center;gap:1rem;font-size:.8rem;color:#777">
    <span style="display:flex;align-items:center;gap:4px"><span style="width:12px;height:12px;background:#ebedf0;border-radius:2px"></span> Tidak aktif</span>
    <span style="display:flex;align-items:center;gap:4px"><span style="width:12px;height:12px;background:#9be9a8;border-radius:2px"></span> Rendah</span>
    <span style="display:flex;align-items:center;gap:4px"><span style="width:12px;height:12px;background:#40c463;border-radius:2px"></span> Sedang</span>
    <span style="display:flex;align-items:center;gap:4px"><span style="width:12px;height:12px;background:#30a14e;border-radius:2px"></span> Tinggi</span>
    <span style="display:flex;align-items:center;gap:4px"><span style="width:12px;height:12px;background:#216e39;border-radius:2px"></span> Sangat Tinggi</span>
</div>
</div>

<!-- Personal Recommendations -->
<div class="section">
<h2>Rekomendasi Personal Berdasarkan Performa</h2>
<div id="personalRecommendations"></div>
</div>

<!-- Bookmarked Materials -->
<div class="section">
<h2>📚 Materi yang Disimpan</h2>
<?php if (empty($bookmarks)): ?>
<p style="color:#777;font-size:.9rem">Belum ada materi yang disimpan. Buka halaman materi untuk bookmark materi yang ingin dipelajari lagi.</p>
<?php else: ?>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:1rem">
    <?php foreach ($bookmarks as $bookmark): 
        $materiId = $bookmark['materi_id'];
        $progress = $bookmark['progress_percent'] ?? 0;
        $subtes = 'TWK';
        if ($materiId > 20) $subtes = 'TIU';
        if ($materiId > 40) $subtes = 'TKP';
    ?>
    <div style="background:#f8f9fa;border-radius:6px;padding:1rem;border-left:4px solid #2980b9">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.5rem">
            <span style="font-size:.75rem;background:#2980b9;color:#fff;padding:.2rem .5rem;border-radius:3px"><?= $subtes ?></span>
            <span style="font-size:.75rem;color:#777">Materi #<?= $materiId ?></span>
        </div>
        <div style="margin-bottom:.5rem">
            <div style="height:4px;background:#e9ecef;border-radius:2px;overflow:hidden">
                <div style="height:100%;background:#27ae60;width:<?= $progress ?>%"></div>
            </div>
            <div style="font-size:.75rem;color:#777;margin-top:.2rem">Progress: <?= $progress ?>%</div>
        </div>
        <a href="materi.php?subtes=<?= $subtes ?>" style="font-size:.85rem;color:#2980b9;text-decoration:none;font-weight:600">
            Lanjut Baca →
        </a>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>
</div>

<?php if (!empty($selesai)): ?>
<!-- Subtes Distribution Pie Chart -->
<div class="section">
<h2>Distribusi Skor Subtes (Tryout Terakhir)</h2>
<?php if (!empty($latestScore) && ($latestScore['nilai_twk'] > 0 || $latestScore['nilai_tiu'] > 0 || $latestScore['nilai_tkp'] > 0)): ?>
<canvas id="pieChart" width="400" height="400" style="max-width:100%;height:auto;margin:0 auto;display:block"></canvas>
<div style="display:flex;justify-content:center;gap:1.5rem;margin-top:1rem;flex-wrap:wrap">
    <div style="display:flex;align-items:center;gap:0.5rem"><span style="width:16px;height:16px;background:#2980b9;border-radius:3px"></span><span style="font-size:.9rem">TWK: <?= $latestScore['nilai_twk'] ?></span></div>
    <div style="display:flex;align-items:center;gap:0.5rem"><span style="width:16px;height:16px;background:#e67e22;border-radius:3px"></span><span style="font-size:.9rem">TIU: <?= $latestScore['nilai_tiu'] ?></span></div>
    <div style="display:flex;align-items:center;gap:0.5rem"><span style="width:16px;height:16px;background:#27ae60;border-radius:3px"></span><span style="font-size:.9rem">TKP: <?= $latestScore['nilai_tkp'] ?></span></div>
</div>
<?php else: ?>
<div style="text-align:center;padding:2rem;color:#777">
<p>Data skor tryout terakhir tidak tersedia atau bernilai 0.</p>
<p style="font-size:.85rem">User ID: <?= $userId ?> | Selesai count: <?= count($selesai) ?> | Latest: <?= $latestScore ? 'exists' : 'null' ?></p>
<?php if ($latestScore): ?>
<p style="font-size:.85rem">Latest scores - TWK: <?= $latestScore['nilai_twk'] ?>, TIU: <?= $latestScore['nilai_tiu'] ?>, TKP: <?= $latestScore['nilai_tkp'] ?></p>
<?php else: ?>
<p style="font-size:.85rem">Debug: selesai array count = <?= count($selesai) ?>, first element exists = <?= isset($selesai[0]) ? 'yes' : 'no' ?></p>
<?php endif; ?>
<p style="font-size:.85rem">Silakan selesaikan tryout untuk melihat distribusi skor.</p>
</div>
<?php endif; ?>
</div>

<script>
// Notification System
let notifDropdownOpen = false;

async function loadNotifications() {
    try {
        const res = await fetch('/api/get_notifications.php?limit=10');
        if (!res.ok) {
            // Silently fail if notifications endpoint is not available
            return;
        }
        const data = await res.json();
        
        if (data.success && data.data) {
            renderNotifications(data.data.notifications);
            updateNotifBadge(data.data.unread_count);
        }
    } catch (e) {
        // Silently fail - notifications are optional
        // Don't log to console to avoid test failures
    }
}

function renderNotifications(notifications) {
    const list = document.getElementById('notifList');
    
    if (!notifications || notifications.length === 0) {
        list.innerHTML = '<p style="color:#777;font-size:.85rem;text-align:center;padding:1rem">Tidak ada notifikasi</p>';
        return;
    }
    
    const typeColors = {
        'info': '#2980b9',
        'success': '#27ae60',
        'warning': '#f39c12',
        'error': '#e74c3c'
    };
    
    let html = '';
    notifications.forEach(n => {
        const bgColor = n.is_read ? '#f8f9fa' : '#eaf2f8';
        html += `
        <div style="background:${bgColor};padding:.8rem;border-bottom:1px solid #eee;cursor:pointer" onclick="openNotification(${n.id}, '${n.link || ''}')" class="notif-item" data-id="${n.id}">
            <div style="display:flex;align-items:center;gap:.5rem;margin-bottom:.3rem">
                <span style="width:8px;height:8px;border-radius:50%;background:${typeColors[n.type]}"></span>
                <span style="font-weight:bold;font-size:.85rem;color:#333">${escapeHtml(n.title)}</span>
                ${!n.is_read ? '<span style="background:#2980b9;color:#fff;font-size:.65rem;padding:.1rem .3rem;border-radius:4px">Baru</span>' : ''}
            </div>
            <div style="font-size:.8rem;color:#555;margin-bottom:.3rem">${escapeHtml(n.message)}</div>
            <div style="font-size:.7rem;color:#999">${new Date(n.created_at).toLocaleString('id-ID')}</div>
        </div>
        `;
    });
    
    html += '<div style="padding:.5rem;text-align:center"><a href="#" onclick="markAllRead();return false" style="font-size:.8rem;color:#2980b9;text-decoration:none">Tandai semua sudah dibaca</a></div>';
    list.innerHTML = html;
}

function updateNotifBadge(count) {
    const badge = document.getElementById('notifBadge');
    if (count > 0) {
        badge.textContent = count > 9 ? '9+' : count;
        badge.style.display = 'inline-block';
    } else {
        badge.style.display = 'none';
    }
}

function toggleNotifications() {
    const dropdown = document.getElementById('notifDropdown');
    notifDropdownOpen = !notifDropdownOpen;
    dropdown.style.display = notifDropdownOpen ? 'block' : 'none';
    
    if (notifDropdownOpen) {
        loadNotifications();
    }
}

async function openNotification(id, link) {
    // Mark as read
    try {
        const formData = new FormData();
        formData.append('notification_id', id);
        await fetch('/api/mark_notification_read.php', { method: 'POST', body: formData });
    } catch (e) {}
    
    // Navigate if link exists
    if (link) {
        window.location.href = link;
    }
    
    // Reload notifications
    loadNotifications();
}

async function markAllRead() {
    try {
        const res = await fetch('/api/get_notifications.php?unread_only=true');
        const data = await res.json();
        
        if (data.success && data.data && data.data.notifications.length > 0) {
            for (const n of data.data.notifications) {
                const formData = new FormData();
                formData.append('notification_id', n.id);
                await fetch('/api/mark_notification_read.php', { method: 'POST', body: formData });
            }
            loadNotifications();
        }
    } catch (e) {}
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Close dropdown when clicking outside
document.addEventListener('click', (e) => {
    const dropdown = document.getElementById('notifDropdown');
    const button = e.target.closest('button[onclick="toggleNotifications()"]');
    if (!button && notifDropdownOpen && !dropdown.contains(e.target)) {
        notifDropdownOpen = false;
        dropdown.style.display = 'none';
    }
});

// Load notifications on page load
document.addEventListener('DOMContentLoaded', loadNotifications);

// Pie Chart
<?php
// $latestScore is already set above after array_values re-index
?>
const pieData = {
    twk: <?= (int)($latestScore['nilai_twk'] ?? 0) ?>,
    tiu: <?= (int)($latestScore['nilai_tiu'] ?? 0) ?>,
    tkp: <?= (int)($latestScore['nilai_tkp'] ?? 0) ?>
};

function drawPieChart(){
    const canvas = document.getElementById('pieChart');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const w = canvas.width, h = canvas.height;
    const centerX = w/2, centerY = h/2, radius = Math.min(w,h)/2 - 40;
    
    const total = pieData.twk + pieData.tiu + pieData.tkp;
    if (total === 0) return;
    
    const data = [
        { label: 'TWK', value: pieData.twk, color: '#2980b9' },
        { label: 'TIU', value: pieData.tiu, color: '#e67e22' },
        { label: 'TKP', value: pieData.tkp, color: '#27ae60' }
    ];
    
    let startAngle = -Math.PI/2;
    
    data.forEach(item => {
        const sliceAngle = (item.value / total) * 2 * Math.PI;
        
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.arc(centerX, centerY, radius, startAngle, startAngle + sliceAngle);
        ctx.closePath();
        ctx.fillStyle = item.color;
        ctx.fill();
        
        // Draw label
        const midAngle = startAngle + sliceAngle/2;
        const labelX = centerX + Math.cos(midAngle) * (radius * 0.7);
        const labelY = centerY + Math.sin(midAngle) * (radius * 0.7);
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 14px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        if (item.value > 0) {
            ctx.fillText(item.label, labelX, labelY - 8);
            ctx.font = '12px Arial';
            ctx.fillText(item.value, labelX, labelY + 8);
        }
        
        startAngle += sliceAngle;
    });
    
    // Draw center circle (donut chart)
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius * 0.4, 0, 2 * Math.PI);
    ctx.fillStyle = '#fff';
    ctx.fill();
    
    // Draw total in center
    ctx.fillStyle = '#333';
    ctx.font = 'bold 16px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Total', centerX, centerY - 10);
    ctx.font = 'bold 24px Arial';
    ctx.fillText(total, centerX, centerY + 15);
}

// Wait for DOM to be ready before drawing chart
document.addEventListener('DOMContentLoaded', drawPieChart);
</script>
<?php endif; ?>

<script src="<?php echo $baseUrl ?? '/permen'; ?>/assets/chart.umd.min.js"></script>
<script>
const chartData = <?= json_encode(array_map(fn($r)=>[
    'date'=>date('d M',strtotime($r['waktu_mulai'])),
    'total'=>(int)($r['total_nilai']??0),
    'tkp'=>(int)($r['nilai_tkp']??0),
    'tiu'=>(int)($r['nilai_tiu']??0),
    'twk'=>(int)($r['nilai_twk']??0)
], array_reverse(array_slice($selesai,-10)))) ?>;

function drawChart(mode){
    const canvas = document.getElementById('progressChart');
    const ctx = canvas.getContext('2d');
    const w = canvas.width, h = canvas.height;
    const pad = {top:30,right:30,bottom:50,left:50};
    ctx.clearRect(0,0,w,h);

    const labels = chartData.map(d=>d.date);
    const values = chartData.map(d=>d[mode]);
    const maxVal = Math.max(...values, 300);
    const minVal = 0;

    // Grid & axes
    ctx.strokeStyle='#eee';ctx.lineWidth=1;
    for(let i=0;i<=5;i++){
        const y=pad.top+(h-pad.top-pad.bottom)*(1-i/5);
        ctx.beginPath();ctx.moveTo(pad.left,y);ctx.lineTo(w-pad.right,y);ctx.stroke();
        ctx.fillStyle='#999';ctx.font='11px Arial';ctx.textAlign='right';
        ctx.fillText(Math.round(maxVal*i/5),pad.left-8,y+4);
    }

    // Bars
    const barW = (w-pad.left-pad.right)/values.length * 0.6;
    const gap = (w-pad.left-pad.right)/values.length;
    const color = mode==='total'?'#2980b9':(mode==='tkp'?'#27ae60':(mode==='tiu'?'#e67e22':'#8e44ad'));

    values.forEach((v,i)=>{
        const x = pad.left + gap*i + gap*0.2;
        const barH = (v/maxVal)*(h-pad.top-pad.bottom);
        const y = h-pad.bottom-barH;
        ctx.fillStyle=color;
        ctx.fillRect(x,y,barW,barH);
        // Value label
        ctx.fillStyle='#333';ctx.font='bold 11px Arial';ctx.textAlign='center';
        ctx.fillText(v, x+barW/2, y-5);
        // Date label
        ctx.save();
        ctx.translate(x+barW/2, h-pad.bottom+15);
        ctx.rotate(-Math.PI/6);
        ctx.fillStyle='#666';ctx.font='10px Arial';
        ctx.fillText(labels[i],0,0);
        ctx.restore();
    });

    // Axis labels
    ctx.fillStyle='#333';ctx.font='bold 12px Arial';ctx.textAlign='center';
    ctx.fillText('Tanggal', w/2, h-5);
    ctx.save();ctx.translate(15,h/2);ctx.rotate(-Math.PI/2);
    ctx.fillText('Nilai ' + mode.toUpperCase(), 0, 0);
    ctx.restore();
}
// Wait for DOM to be ready before drawing chart
document.addEventListener('DOMContentLoaded', () => drawChart('total'));

// Enhanced Analytics with Chart.js
let progressChart = null;
let comparisonChart = null;

async function loadAnalytics() {
    try {
        const response = await fetch('/api/get_dashboard_analytics.php');
        const data = await response.json();
        
        if (data.success) {
            initLineChart(data.data.score_progress);
            initComparisonChart(data.data.user_average, data.data.national_average);
            initHeatmap(data.data.learning_activity);
            initRecommendations(data.data.weak_topics);
        }
    } catch (error) {
        console.error('Failed to load analytics:', error);
    }
}

function initLineChart(scoreData) {
    const ctx = document.getElementById('progressChart');
    if (!ctx) return;
    
    const labels = scoreData.map(d => {
        const date = new Date(d.date);
        return date.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });
    });
    
    const datasets = [
        {
            label: 'Total',
            data: scoreData.map(d => d.total_nilai),
            borderColor: '#2980b9',
            backgroundColor: 'rgba(41, 128, 185, 0.1)',
            tension: 0.3,
            fill: true
        },
        {
            label: 'TKP',
            data: scoreData.map(d => d.nilai_tkp),
            borderColor: '#27ae60',
            backgroundColor: 'rgba(39, 174, 96, 0.1)',
            tension: 0.3,
            fill: true,
            hidden: true
        },
        {
            label: 'TIU',
            data: scoreData.map(d => d.nilai_tiu),
            borderColor: '#e67e22',
            backgroundColor: 'rgba(230, 126, 34, 0.1)',
            tension: 0.3,
            fill: true,
            hidden: true
        },
        {
            label: 'TWK',
            data: scoreData.map(d => d.nilai_twk),
            borderColor: '#8e44ad',
            backgroundColor: 'rgba(142, 68, 173, 0.1)',
            tension: 0.3,
            fill: true,
            hidden: true
        }
    ];
    
    progressChart = new Chart(ctx, {
        type: 'line',
        data: { labels, datasets },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: { font: { size: 12 } }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 350,
                    title: { display: true, text: 'Nilai' }
                },
                x: {
                    title: { display: true, text: 'Tanggal' }
                }
            }
        }
    });
}

function updateLineChart(mode) {
    if (!progressChart) return;
    
    const modeMap = { 'total': 0, 'tkp': 1, 'tiu': 2, 'twk': 3 };
    const index = modeMap[mode];
    
    progressChart.data.datasets.forEach((ds, i) => {
        ds.hidden = i !== index;
    });
    
    progressChart.update();
}

function initComparisonChart(userAvg, nationalAvg) {
    const ctx = document.getElementById('comparisonChart');
    if (!ctx) return;
    
    comparisonChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['TKP', 'TIU', 'TWK', 'Total'],
            datasets: [
                {
                    label: 'Nilai Anda',
                    data: [userAvg.tkp, userAvg.tiu, userAvg.twk, userAvg.total],
                    backgroundColor: 'rgba(41, 128, 185, 0.8)',
                    borderColor: '#2980b9',
                    borderWidth: 1
                },
                {
                    label: 'Rata-rata Nasional',
                    data: [nationalAvg.tkp, nationalAvg.tiu, nationalAvg.twk, nationalAvg.total],
                    backgroundColor: 'rgba(230, 126, 34, 0.8)',
                    borderColor: '#e67e22',
                    borderWidth: 1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: { font: { size: 12 } }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 350,
                    title: { display: true, text: 'Nilai' }
                }
            }
        }
    });
}

function initHeatmap(activityData) {
    const container = document.getElementById('activityHeatmap');
    if (!container) return;
    
    // Create activity map for last 30 days
    const activityMap = {};
    activityData.forEach(d => {
        activityMap[d.activity_date] = d.session_count;
    });
    
    const heatmap = document.createElement('div');
    heatmap.style.display = 'grid';
    heatmap.style.gridTemplateColumns = 'repeat(7, 1fr)';
    heatmap.style.gap = '4px';
    heatmap.style.maxWidth = '400px';
    heatmap.style.margin = '0 auto';
    
    for (let i = 29; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dateStr = date.toISOString().split('T')[0];
        const sessions = activityMap[dateStr] || 0;
        
        const cell = document.createElement('div');
        cell.style.width = '40px';
        cell.style.height = '40px';
        cell.style.borderRadius = '4px';
        cell.style.display = 'flex';
        cell.style.alignItems = 'center';
        cell.style.justifyContent = 'center';
        cell.style.fontSize = '10px';
        cell.style.color = '#fff';
        cell.style.fontWeight = 'bold';
        
        // Color based on activity level
        if (sessions === 0) {
            cell.style.background = '#ebedf0';
            cell.style.color = '#777';
        } else if (sessions === 1) {
            cell.style.background = '#9be9a8';
        } else if (sessions === 2) {
            cell.style.background = '#40c463';
        } else if (sessions === 3) {
            cell.style.background = '#30a14e';
        } else {
            cell.style.background = '#216e39';
        }
        
        cell.title = `${dateStr}: ${sessions} sesi`;
        if (sessions > 0) {
            cell.textContent = sessions;
        }
        
        heatmap.appendChild(cell);
    }
    
    container.appendChild(heatmap);
}

function initRecommendations(weakTopics) {
    const container = document.getElementById('personalRecommendations');
    if (!container) return;
    
    if (weakTopics.length === 0) {
        container.innerHTML = '<p style="color:#777;font-size:.9rem">Belum cukup data untuk memberikan rekomendasi. Selesaikan lebih banyak tryout!</p>';
        return;
    }
    
    let html = '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:1rem">';
    
    weakTopics.forEach(topic => {
        const accuracyColor = topic.accuracy < 40 ? '#e74c3c' : (topic.accuracy < 70 ? '#f39c12' : '#27ae60');
        const urgency = topic.accuracy < 40 ? 'Sangat Lemah' : (topic.accuracy < 70 ? 'Perlu Perhatian' : 'Cukup Baik');
        
        html += `
        <div style="background:#f8f9fa;border-left:4px solid ${accuracyColor};border-radius:6px;padding:1rem">
            <div style="font-weight:bold;color:#1a5276;margin-bottom:.3rem">${topic.subtes} — ${topic.topik}</div>
            <div style="font-size:.9rem;color:#555;margin-bottom:.5rem">
                Akurasi: <span style="color:${accuracyColor};font-weight:bold">${topic.accuracy}%</span> (${topic.correct}/${topic.total} soal)
            </div>
            <div style="font-size:.8rem;color:#777;margin-bottom:.5rem">Status: ${urgency}</div>
            <a href="materi.php?subtes=${topic.subtes}" style="font-size:.85rem;color:#2980b9;text-decoration:none;font-weight:600">
                Pelajari Materi Ini →
            </a>
        </div>
        `;
    });
    
    html += '</div>';
    container.innerHTML = html;
}

// Load analytics on page load
document.addEventListener('DOMContentLoaded', loadAnalytics);
</script>
<?php endif; ?>

<?php if (empty($topikStats)): ?>
<!-- Empty State for Topik Stats -->
<div class="section" style="text-align:center;padding:2rem 1rem">
<div style="font-size:2rem;margin-bottom:.5rem">📚</div>
<p style="color:#777;font-size:.9rem">Selesaikan lebih banyak soal untuk melihat analisis akurasi per topik.</p>
</div>
<?php else: ?>
<!-- Analisis Akurasi per Topik -->
<div class="section">
<h2>Analisis Akurasi per Topik</h2>
<p style="font-size:.9rem;color:#555;margin-bottom:1rem">Persentase jawaban benar per topik (minimal 3 soal dikerjakan). Semakin tinggi semakin baik.</p>
<div class="topic-grid">
<?php foreach ($topikStats as $ts):
    $pct = round(($ts['benar'] / $ts['total']) * 100);
    $fillClass = $pct >= 70 ? 'high' : ($pct >= 40 ? 'mid' : 'low');
    $badgeColor = $pct >= 70 ? '#27ae60' : ($pct >= 40 ? '#f39c12' : '#e74c3c');
?>
<div style="background:#f8f9fa;border-radius:6px;padding:.8rem">
    <div class="topic-bar">
        <div class="topic-bar-header">
            <span><strong><?= $ts['subtes'] ?></strong> — <?= e($ts['topik']) ?></span>
            <span style="color:<?= $badgeColor ?>;font-weight:bold"><?= $pct ?>% (<?= $ts['benar'] ?>/<?= $ts['total'] ?>)</span>
        </div>
        <div class="topic-bar-track">
            <div class="topic-bar-fill <?= $fillClass ?>" style="width:<?= $pct ?>%"></div>
        </div>
    </div>
    <div style="text-align:right;margin-top:.3rem">
        <a href="materi.php?subtes=<?= $ts['subtes'] ?>" style="font-size:.8rem;color:#2980b9;text-decoration:none">Latih Topik Ini &rarr;</a>
    </div>
</div>
<?php endforeach; ?>
</div>
</div>
<?php endif; ?>

<?php if ($subtesTerlemah !== '-'): ?>
<div class="rekomendasi">
<h3>Analisis Kelemahan & Rekomendasi</h3>
<p>Subtes <strong><?= $subtesTerlemah ?></strong> adalah nilai rata-rata terendah Anda (rata-rata: <?= $subtesTerlemah === 'TKP' ? $avgTkp : ($subtesTerlemah === 'TIU' ? $avgTiu : $avgTwk) ?>).</p>
<?php
// Filter rekomendasi materi berdasarkan subtes terlemah
$rekomSub = array_filter($rekomendasiMateri, fn($r) => $r['subtes'] === $subtesTerlemah);
if (!empty($rekomSub)):
?>
<ul style="margin-top:.5rem;padding-left:1.2rem;font-size:.9rem;color:#444">
<?php foreach (array_slice($rekomSub, 0, 3) as $r): ?>
<li><a href="<?= $r['materi_url'] ?>" style="color:#2980b9;text-decoration:none"><?= e($r['topik']) ?></a> — <?= e($r['pesan']) ?></li>
<?php endforeach; ?>
</ul>
<?php endif; ?>
</div>
<?php endif; ?>

<?php if (!empty($selesai)): 
    $latest = reset($selesai); // Tryout terakhir yang selesai
    $latestTkp = $latest['nilai_tkp'] ?? 0;
    $latestTiu = $latest['nilai_tiu'] ?? 0;
    $latestTwk = $latest['nilai_twk'] ?? 0;
    $latestTotal = $latest['total_nilai'] ?? 0;
?>
<div class="section" style="margin-top:1.2rem">
<h2>Kelayakan SKD</h2>
<p style="font-size:.9rem;color:#555;margin-bottom:1rem">
<strong>Passing Grade Standar BKN 2024:</strong> TKP 156, TIU 80, TWK 65, Total 301 (semua instansi menggunakan standar yang sama).
</p>
<p style="font-size:.9rem;color:#555;margin-bottom:1rem">
Berdasarkan nilai tryout terakhir Anda (TKP: <?= $latestTkp ?>, TIU: <?= $latestTiu ?>, TWK: <?= $latestTwk ?>, Total: <?= $latestTotal ?>):
</p>
<?php
$lulusTkp = $latestTkp >= 156;
$lulusTiu = $latestTiu >= 80;
$lulusTwk = $latestTwk >= 65;
$lulusTotal = $latestTotal >= 301;
$lulusSemua = $lulusTkp && $lulusTiu && $lulusTwk && $lulusTotal;
?>
<div style="background:<?= $lulusSemua ? '#d4edda' : '#fff3cd' ?>;border:1px solid <?= $lulusSemua ? '#155724' : '#856404' ?>;border-radius:6px;padding:1rem;margin-bottom:1rem">
<div style="font-weight:bold;color:#1a5276;font-size:1rem;margin-bottom:.5rem">
<?= $lulusSemua ? '✅ Memenuhi Syarat SKD' : '⚠️ Belum Memenuhi Syarat SKD' ?>
</div>
<div style="font-size:.9rem;color:#555">
<?php if ($lulusSemua): ?>
Nilai Anda memenuhi passing grade standar BKN. Anda berpotensi lolos ke tahap seleksi berikutnya untuk semua instansi.
<?php else: ?>
Anda perlu meningkatkan nilai di subtes berikut:
<?php if (!$lulusTkp) echo '<br>• TKP: kurang ' . (156 - $latestTkp); ?>
<?php if (!$lulusTiu) echo '<br>• TIU: kurang ' . (80 - $latestTiu); ?>
<?php if (!$lulusTwk) echo '<br>• TWK: kurang ' . (65 - $latestTwk); ?>
<?php if (!$lulusTotal) echo '<br>• Total: kurang ' . (301 - $latestTotal); ?>
<?php endif; ?>
</div>
</div>
<?php if ($userInfo['instansi_nama']): ?>
<div style="background:#eaf2f8;border-left:4px solid #2980b9;border-radius:0 6px 6px 0;padding:1rem">
<div style="font-weight:bold;color:#1a5276">Instansi Pilihan Anda: <?= e($userInfo['instansi_kode']) ?> — <?= e($userInfo['instansi_nama']) ?></div>
<div style="font-size:.9rem;color:#555;margin-top:.3rem">
<?= $lulusSemua ? '✅ Nilai Anda memenuhi passing grade instansi ini.' : '⚠️ Nilai Anda belum memenuhi passing grade instansi ini.' ?>
</div>
</div>
<?php else: ?>
<div style="background:#f8f9fa;border-left:4px solid #999;border-radius:0 6px 6px 0;padding:1rem">
<div style="font-size:.9rem;color:#555">
Belum memilih instansi pilihan. <a href="profile.php" style="color:#2980b9">Pilih instansi di profil</a> untuk melihat status kelayakan spesifik.
</div>
</div>
<?php endif; ?>
</div>
<?php endif; ?>

<?php
// Fetch riwayat daily quiz
$dailyQuizHistory = $pdo->prepare("SELECT * FROM daily_quiz_sessions WHERE user_id = ? AND status = 'completed' ORDER BY quiz_date DESC LIMIT 7");
$dailyQuizHistory->execute([$userId]);
$dailyHistory = $dailyQuizHistory->fetchAll();
?>

<!-- Daily Quiz Section -->
<div class="section">
<h2>Daily Quiz</h2>
<?php if (empty($dailyHistory)): ?>
<div class="empty">Mulai Daily Quiz untuk latihan harian 10 soal campuran!</div>
<div style="text-align:center;margin-top:1rem">
<a href="daily_quiz.php" class="btn" style="background:#e74c3c">Mulai Daily Quiz</a>
</div>
<?php else: ?>
<div class="table-wrap">
<table>
<thead>
<tr><th>Tanggal</th><th>Benar</th><th>Salah</th><th>Kosong</th><th>Nilai</th></tr>
</thead>
<tbody>
<?php foreach ($dailyHistory as $dh): ?>
<tr>
<td><?= date('d M Y', strtotime($dh['quiz_date'])) ?></td>
<td style="color:#27ae60;font-weight:bold"><?= $dh['benar'] ?></td>
<td style="color:#e74c3c"><?= $dh['salah'] ?></td>
<td style="color:#95a5a6"><?= $dh['kosong'] ?></td>
<td style="font-weight:bold;color:#2980b9"><?= $dh['nilai_total'] ?></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
<div style="text-align:center;margin-top:1rem">
<a href="daily_quiz.php" class="btn" style="background:#e74c3c">Kerjakan Daily Quiz Hari Ini</a>
</div>
<?php endif; ?>
</div>

<div class="section">
<h2>Riwayat Tryout</h2>
<?php if (empty($riwayat)): ?>
<div class="empty">Belum ada riwayat tryout. Yuk mulai latihan!</div>
<?php else: ?>
<div class="table-wrap">
<table>
<thead>
<tr><th>Nama</th><th>Status</th><th>TKP</th><th>TIU</th><th>TWK</th><th>Total</th><th>Waktu</th></tr>
</thead>
<tbody>
<?php foreach ($riwayat as $r):
    $tkpStatus = ($r['nilai_tkp'] ?? 0) >= $passingTkp ? 'lulus' : 'gagal';
    $tiuStatus = ($r['nilai_tiu'] ?? 0) >= $passingTiu ? 'lulus' : 'gagal';
    $twkStatus = ($r['nilai_twk'] ?? 0) >= $passingTwk ? 'lulus' : 'gagal';
?>
<tr style="cursor:pointer" onclick="window.location.href='hasil.php?session_id=<?= $r['id'] ?>'">
<td><?= e($r['nama']) ?></td>
<td><span class="badge <?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span></td>
<td><span class="badge <?= $tkpStatus ?>"><?= $r['nilai_tkp'] ?? 0 ?></span></td>
<td><span class="badge <?= $tiuStatus ?>"><?= $r['nilai_tiu'] ?? 0 ?></span></td>
<td><span class="badge <?= $twkStatus ?>"><?= $r['nilai_twk'] ?? 0 ?></span></td>
<td><?= $r['total_nilai'] ?? 0 ?></td>
<td><?= date('d M Y H:i', strtotime($r['waktu_mulai'])) ?></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
<?php endif; ?>
</div>

</div>

<div class="footer">
Dashboard Peserta SKD CAT-BKN | Latihan persiapan Sekolah Kedinasan
</div>
<script>
// Dark mode toggle
function toggleTheme() {
    const current = document.documentElement.getAttribute('data-theme');
    const next = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('theme', next);
}
// Load saved theme
const savedTheme = localStorage.getItem('theme');
if (savedTheme) {
    document.documentElement.setAttribute('data-theme', savedTheme);
}
// Notifications toggle
function toggleNotifications() {
    const dropdown = document.getElementById('notifDropdown');
    dropdown.style.display = dropdown.style.display === 'none' ? 'block' : 'none';
}
</script>
</body>
</html>
