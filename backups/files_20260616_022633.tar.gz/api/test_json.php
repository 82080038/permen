<?php
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['test' => 'success', 'time' => time()]);
